# msb/base/__init__.py
from .baseentity import BaseEntity
from .basecontainer import BaseContainer

__all__ = ["BaseEntity", "BaseContainer"]